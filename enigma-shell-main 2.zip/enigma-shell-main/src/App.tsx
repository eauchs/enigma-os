import React, { useState, useRef } from 'react';
// On importe le composant ET son type de ref
import Emulator, { EmulatorRef } from './components/Emulator';

// Le type pour l'état de l'agent
type AgentState = 'snapshot' | ArrayBuffer | null;

function App() {
  const [status, setStatus] = useState('Initializing Host...');
  const [isReadyForInput, setIsReadyForInput] = useState(false);
  
  // On démarre par défaut depuis le snapshot.
  // La variable 'setInitialState' est retirée car non utilisée (pour l'instant).
  const [initialState] = useState<AgentState>('snapshot');

  // On type la ref. C'est la correction clé pour l'erreur "serial0_send".
  const emulatorRef = useRef<EmulatorRef | null>(null);

  // Cette fonction est appelée quand l'émulateur est prêt
  const handleEmulatorReady = () => {
    setStatus('VM Ready. Logging in and starting GUI...');
    setIsReadyForInput(false); // On bloque l'input pendant le démarrage

    // Séquence de démarrage automatisée pour Arch Linux
    const startupSequence = [
      { cmd: 'root\n', delay: 2000 },       // Commande pour se logger
      { cmd: './startx.sh\n', delay: 5000 }  // Commande pour lancer le bureau
    ];

    let cumulativeDelay = 0;
    startupSequence.forEach(step => {
      cumulativeDelay += step.delay;
      setTimeout(() => {
        // On vérifie que la ref est bien initialisée
        if (emulatorRef.current) {
          console.log(`Automating command: ${step.cmd.trim()}`);
          emulatorRef.current.serial0_send(step.cmd);
        }
      }, cumulativeDelay);
    });
    
    // On attend la fin de la séquence pour débloquer l'input
    setTimeout(() => {
      setStatus('Agent GUI is running. Ready for VLM control.');
      setIsReadyForInput(true);
    }, cumulativeDelay + 3000); // Marge de sécurité
  };

  // C'est ici qu'on enverra les objectifs au VLM (plus tard)
  const handleObjectiveSubmit = (objective: string) => {
    if (!isReadyForInput) return;
    console.log("New objective for VLM:", objective);
    setStatus(`Objective received: "${objective}"`);
    // TODO: Implémenter la logique VLM (screenshot + appel Ollama)
  };

  return (
    // L'import de 'React' corrige les erreurs "Property 'div' does not exist"
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#1e1e1e', color: 'white' }}>
      <header style={{ padding: '10px', background: '#252526', textAlign: 'center', flexShrink: 0 }}>
        <h1>Sovereign Agent Host</h1>
        <p>Status: {status}</p>
      </header>
      <main style={{ flex: 1, padding: '10px', minHeight: 0 }}>
        <Emulator 
            ref={emulatorRef}
            // On ne passe l'état que si ce n'est PAS 'snapshot'
            // Cette logique gère le cas 'null' implicitement car 'initialState' est toujours 'snapshot'
            initialState={initialState !== 'snapshot' ? initialState : undefined}
            onReady={handleEmulatorReady}
        />
      </main>
      <footer style={{ padding: '10px', flexShrink: 0 }}>
        <input 
          type="text" 
          placeholder="Enter objective for the agent..." 
          disabled={!isReadyForInput}
          // On type l'événement 'e' pour corriger l'erreur d'inférence
          onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
            if (e.key === 'Enter') {
              handleObjectiveSubmit(e.currentTarget.value);
              e.currentTarget.value = '';
            }
          }}
          style={{ width: '100%', padding: '10px', background: '#3c3c3c', border: '1px solid #555', color: 'white', borderRadius: '5px' }}
        />
      </footer>
    </div>
  );
}

export default App;