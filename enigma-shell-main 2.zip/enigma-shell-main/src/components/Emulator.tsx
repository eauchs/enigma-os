import React, { forwardRef, useImperativeHandle, useRef, useEffect } from 'react';

// On définit les types pour que TypeScript comprenne ce que notre composant peut faire
export interface EmulatorRef {
  serial0_send: (cmd: string) => void;
  saveState: () => Promise<ArrayBuffer | null>;
}

interface EmulatorProps {
  initialState?: ArrayBuffer | null;
  onReady?: () => void;
}

// Déclaration globale pour que TypeScript connaisse V86Starter
declare global {
  interface Window {
    V86Starter: any;
  }
}

// On type les props et la ref
const Emulator = forwardRef<EmulatorRef, EmulatorProps>(({ initialState, onReady }, ref) => {
  const screenContainerRef = useRef<HTMLDivElement>(null);
  const emulatorInstance = useRef<any>(null);

  useEffect(() => {
    // On vérifie que le script v86 est bien chargé ET que la div est prête
    if (window.V86Starter && screenContainerRef.current) {
      const config: any = { 
        screen_container: screenContainerRef.current,
        wasm_path: { url: "/v86/v86.wasm"}, // <--- AJOUTE CETTE LIGNE
        bios: { url: "/v86/seabios.bin" },
        vga_bios: { url: "/v86/vgabios.bin" },
        autostart: true,
      };

      if (initialState) {
        // Priorité 1 : L'utilisateur a déjà une "Âme" sauvegardée.
        console.log("Restoring agent from saved Âme...");
        config.initial_state = initialState;
      } else {
        // Priorité 2 : C'est le tout premier démarrage. On utilise le snapshot local.
        console.log("First boot detected. Using local Arch Linux snapshot.");
        // Le chemin pointe vers /public/images/arch_state-v3.bin.zst
        config.initial_state = { url: "images/arch_state-v3.bin.zst" };
      }

      emulatorInstance.current = new window.V86Starter(config);
      
      emulatorInstance.current.add_listener("emulator-ready", () => {
          console.log("Emulator is technically ready.");
          if(onReady) onReady();
      });

    } else {
      console.error("v86 script not loaded or screen container not ready.");
    }

    return () => {
      if (emulatorInstance.current) {
        emulatorInstance.current.destroy();
        emulatorInstance.current = null;
      }
    };
  }, [initialState, onReady]);

  // Expose les fonctions au composant parent (App.tsx)
  useImperativeHandle(ref, () => ({
    serial0_send: (cmd: string) => {
      if (emulatorInstance.current) {
        emulatorInstance.current.serial0_send(cmd);
      }
    },
    saveState: async () => {
      if (emulatorInstance.current) {
        // Appelle la fonction de sauvegarde de v86
        return await emulatorInstance.current.save_state();
      }
      return null;
    }
  }));

  // C'est l'écran de la VM
  return <div ref={screenContainerRef} style={{ width: '100%', height: '100%', background: 'black' }} />;
});

export default Emulator;